from flask import Flask, request , jsonify
from flask_cors import CORS, cross_origin


from model import db, Request 
from serialize import serializerRequest



app = Flask(__name__)
CORS(app, supports_credentials=True)
db.init_app(app)
with app.app_context():
    #db.drop_all()
    db.create_all()
    print("database active")




@app.route('/', methods=['GET'])
def testing():

      return jsonify({

            "greetings":"hello"
            
        }
    )
@app.route('/submitting_the_form', methods=['POST'])
def submit_form():


#age,gender,allergies,phonenumber,pregnant,description,symptoms,pharmacist
    age = request.json["age"]
    gender = request.json["gender"]
    allergy = request.json["allergy"]
    current_medications = request.json["current_medications"]
    phone_number = request.json["phone_number"]
    pregnant = request.json["pregnant"]
    description = request.json["description"]
    symptom = request.json["symptom"]
    pharmacist = request.json["pharmacist"]

    new_request =Request(age=age,gender =gender,allergy=allergy,current_medications=current_medications,phone_number=phone_number,pregnant=pregnant,description=description,symptom=symptom,pharmacist=pharmacist )
    db.session.add(new_request)
    db.session.commit()
    print("testing print statement")
    print("age:" + new_request.age,"req_id:" + str(new_request.req_id))
    return jsonify({

        "msg":"success",
        "req_id":new_request.req_id
        
    })


@app.route('/retrieval_of_queue_information', methods=['GET'])
def send_all_info():
    request = Request.query.all()
    return jsonify(

        [*map(serializerRequest,request)]
            
        
    )


@app.route('/fuflling_a_queue/<int:req_id>', methods=['PUT'])
def delete_one_request(req_id):
    old_req_id=str(Request.query.filter_by(req_id=req_id).first())
    Request.query.filter_by(req_id=req_id).delete()
    db.session.commit()
    return jsonify({
        "msg":"succuesffuly removed" +old_req_id
    })


if __name__ == "__main__":
    app.run(debug=True)