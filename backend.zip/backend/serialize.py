def serializerRequest(object):
	return{

        'req_id':object.req_id,
		'age':object.age,
		'gender':object.gender,
		'allergy': object.allergy,
		'current_medications': object.current_medications,
		'phone_number': object.phone_number,
		'pregnant':object.pregnant,
        'description':object.description,
        'symptom':object.symptom,
        'pharmacist':object.pharmacist,
	}